const result = document.querySelector('#result');
const expression = document.querySelector('#expression');
const num = document.querySelectorAll('.number');
const operation = document.querySelectorAll('.operation');
const equals = document.querySelector(".equals");
const clear = document.querySelector('#clear');
const ce = document.querySelector('#ce');
let ex = '';
result.innerHTML = '0';


function clickN () {
    if (!ex || typeof ex === "number" || ex === "0") {
        expression.innerHTML = this.id;
        ex = this.id;
    } else {
        expression.innerHTML += this.id;
        ex += this.id
    }
    result.innerHTML = ex.split(/\/|\*|\+|-|=/).pop() ;
    CheckLength(result.innerHTML)
}

function clickO () {
    if (!ex) {
        return; 
    }
    expression.innerHTML = expression.innerHTML + this.id;
    ex += this.id;
    result.innerHTML = this.id;
}

num.forEach ( el => {
    el.addEventListener('click', clickN)
});
console.log(num);

operation.forEach ( (el) => {
    el.addEventListener('click', clickO)
});
console.log(num);

clear.addEventListener('click', () => {
    result.innerHTML = "";
    expression.innerHTML = "";
    ex = "";
})

equals.addEventListener('click', () => {
    if (!ex) {
        result.innerHTML = "0";
    } else {
        ex = eval(ex);
        expression.innerHTML += "=";
        result.innerHTML = ex;
    }
})

function CheckLength (arg) {
    if (arg.toString().length > 14 ) {
    expression.innerHTML = "Число слишком большое";
    result.innerHTML = '0';
    ex = '0';
}}


